SEQUÊNCIA PARA CRIAR O PROJETO
Criar o projeto react
### npx create-react-app esinais

Acessar diretório do projeto
### cd esinais

Rodar o projeto react
## npm start

RODANDO O PROJETO COM OS ARQUIVOS BAIXADOS NO COMPUTADOR (dependências do arquivo packege)
### npm install 

Rodar o projeto
### npm start

Gerenciar rotas (Se atualizar para nova versão terá que mudar as rotas privadas)
### npm install react-router-dom@5.2.0

Realizar chamadas para API
### npm install --save axios

Utilizado para mudar de página e renderizar a nova página sem recarregar toda aplicação
### npm install --save history@4.10.1

Dependência para validar as informações do campos no front-end
### npm install --save yup

Dependência para edição de vídeo
### npm install --save 
### npm install --save react-file-drop

Dependência Classnames
### npm install classname --save

Dependência do FOOTER
### npm install --save cdbreact

Instalação do menu responsivo
### npm install react-pro-sidebar

